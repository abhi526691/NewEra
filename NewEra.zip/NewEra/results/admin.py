from django.contrib import admin
from .models import DeclareResult
# Register your models here.

admin.site.register(DeclareResult)
